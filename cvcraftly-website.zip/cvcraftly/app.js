const storageKey = "cvcraftly-credit-demo-v2";
const $ = (selector) => document.querySelector(selector);
const money = (value) => new Intl.NumberFormat("en-NG").format(Number(value) || 0);
const clean = (value) => String(value || "").replace(/[&<>'"]/g, (char) => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", "'":"&#39;", '"':"&quot;" }[char]));
const initial = { currentEmail: null, accounts: [], transfers: [], notice: null };
const state = { ...initial, ...JSON.parse(localStorage.getItem(storageKey) || "{}") };
const save = () => localStorage.setItem(storageKey, JSON.stringify(state));
const activeAccount = () => state.accounts.find((account) => account.email === state.currentEmail) || null;
const isSuperAdmin = () => activeAccount()?.role === "superadmin";
const activity = (account, title, detail, amount = 0, type = "positive") => { account.activity = account.activity || []; account.activity.unshift({ title, detail, amount, type, at: new Date().toLocaleString() }); };
const emailNotice = (account, subject) => { activity(account, "Email notification queued", `${subject} — ${account.email}`, 0, "positive"); };

function openAuth(mode) {
  const signup = mode === "signup";
  $("#authEyebrow").textContent = signup ? "Welcome to CVCraftly" : "Welcome back";
  $("#authTitle").textContent = signup ? "Create your account" : "Log in to your account";
  $("#authCopy").textContent = signup ? "Use your email and password. We will send a verification email and add 10 free credits." : "Use your email and password to access your CVs and credit wallet.";
  $("#authSubmit").textContent = signup ? "Create account + get 10 credits" : "Log in";
  $("#authEmail").type = signup ? "email" : "text";
  $("#authEmail").placeholder = signup ? "you@example.com" : "Email or admin username";
  $("#authPassword").autocomplete = signup ? "new-password" : "current-password";
  $("#authForm").dataset.mode = mode;
  $("#authSwitch").innerHTML = signup ? "Already have an account? <button type=\"button\">Log in</button>" : "New to CVCraftly? <button type=\"button\">Create an account</button>";
  $("#authSwitch button").onclick = () => openAuth(signup ? "login" : "signup");
  $("#authDialog").showModal();
}

function showNotice(title, copy) { state.notice = { title, copy }; save(); }
function panel(name) {
  document.querySelectorAll(".panel").forEach((item) => item.classList.toggle("active", item.id === name));
  document.querySelectorAll(".side").forEach((item) => item.classList.toggle("active", item.dataset.panel === name));
  $("#dashboard").classList.remove("menu-open"); $("#accountDropdown").hidden = true;
}

function renderAdmin() {
  const admin = $("#admin");
  if (!isSuperAdmin()) { admin.innerHTML = ""; return; }
  const users = state.accounts.filter((account) => account.role !== "superadmin");
  const pending = state.transfers.filter((transfer) => transfer.status === "Pending");
  admin.innerHTML = `<p class="eyebrow">Super-admin control centre</p><h2>Users, credits and payment confirmations</h2><p class="muted">Manage user accounts and issue credits manually.</p><div class="admin-cards"><article><span>Registered users</span><strong>${users.length}</strong></article><article><span>Pending transfers</span><strong>${pending.length}</strong></article><article><span>Credits issued</span><strong>${money(users.reduce((sum, user) => sum + user.credits, 0))}</strong></article></div><section class="admin-table"><h3>Manual credit controls</h3><form class="admin-credit-form" id="manualCreditForm"><label>User<select id="adminUser" required>${users.length ? users.map((user) => `<option value="${clean(user.email)}">${clean(user.email)} — ${money(user.credits)} credits</option>`).join("") : "<option>No users yet</option>"}</select></label><label>Credits to issue<input id="adminCreditAmount" inputmode="numeric" min="1" value="100" required></label><button class="button dark" ${users.length ? "" : "disabled"}>Add credits manually</button></form><p id="adminCreditNote" class="note"></p></section><section class="admin-table"><h3>Bank transfer confirmations</h3>${pending.length ? pending.map((transfer) => `<div class="request"><span><strong>${clean(transfer.email)}</strong><small>₦${money(transfer.amount)} · ${clean(transfer.reference)}</small></span><button class="button light approve-transfer" data-transfer="${transfer.id}">Confirm & issue ${money(transfer.amount)} credits</button></div>`).join("") : "<p class=\"muted\">No bank transfers waiting for confirmation.</p>"}</section><section class="admin-table"><h3>Manage users</h3>${users.length ? users.map((user) => `<div class="request"><span><strong>${clean(user.email)}</strong><small>${money(user.credits)} credits · ${user.cvs || 0} CVs · ${user.verified ? "verified" : "verification pending"}</small></span><button class="button light view-user" data-user="${clean(user.email)}">View activity</button></div>`).join("") : "<p class=\"muted\">User accounts will appear here after sign-up.</p>"}<p class="note" id="userActivityNote"></p></section>`;
  $("#manualCreditForm")?.addEventListener("submit", (event) => { event.preventDefault(); const user = state.accounts.find((account) => account.email === $("#adminUser").value); const amount = Math.max(1, Number($("#adminCreditAmount").value) || 0); if (!user) return; user.credits += amount; activity(user, "Credits added", `${money(amount)} credits added by super-admin`, amount); emailNotice(user, "Your CVCraftly credits have been added"); showNotice("Credits added", `${money(amount)} credits have been issued to ${user.email}. An email notification has been queued.`); save(); render(); });
  document.querySelectorAll(".approve-transfer").forEach((button) => button.onclick = () => { const transfer = state.transfers.find((item) => String(item.id) === button.dataset.transfer); const user = state.accounts.find((account) => account.email === transfer?.email); if (!transfer || !user) return; transfer.status = "Confirmed"; user.credits += transfer.amount; activity(user, "Bank transfer confirmed", `${money(transfer.amount)} credits issued after bank transfer`, transfer.amount); emailNotice(user, "Your bank-transfer credits are available"); showNotice("Payment confirmed", `${money(transfer.amount)} credits were issued and an email notification was queued.`); save(); render(); });
  document.querySelectorAll(".view-user").forEach((button) => button.onclick = () => { const user = state.accounts.find((account) => account.email === button.dataset.user); $("#userActivityNote").textContent = user?.activity?.length ? user.activity.slice(0, 3).map((item) => `${item.title}: ${item.detail}`).join(" · ") : "No activity recorded yet."; });
}

function render() {
  const user = activeAccount(); const signedIn = Boolean(user);
  $("#home").hidden = signedIn; $("#dashboard").hidden = !signedIn; $(".topbar").hidden = signedIn; $("body > footer").hidden = signedIn;
  if (!signedIn) return;
  $("#welcomeName").textContent = user.role === "superadmin" ? "Platform operations" : "Welcome back";
  $("#accountName").textContent = user.role === "superadmin" ? "Super Admin" : user.email.split("@")[0];
  $("#accountEmail").textContent = user.email; $("#avatar").textContent = user.email[0].toUpperCase();
  ["#creditBalance", "#walletBalance", "#dropdownCredits", "#personalCredits"].forEach((id) => $(id).textContent = money(user.credits));
  $("#walletNaira").textContent = `₦${money(user.credits)} value`; $("#cvCount").textContent = user.cvs || 0;
  $("#personalEmail").textContent = user.email; $("#personalVerification").textContent = user.verified ? "Verified" : "Verification email sent";
  $("#adminTab").hidden = !isSuperAdmin();
  const notice = state.notice; $("#creditNotice").hidden = !notice; if (notice) { $("#noticeTitle").textContent = notice.title; $("#noticeCopy").textContent = notice.copy; }
  const entries = user.activity?.length ? user.activity : [{ title: "Welcome credits", detail: "Added at sign-up", amount: 10, type: "positive" }];
  $("#transactionList").innerHTML = entries.slice(0, 8).map((item) => `<div class="transaction"><span><strong>${clean(item.title)}</strong><small>${clean(item.detail)}</small></span><span class="${item.type}">${item.amount > 0 ? "+" : ""}${money(item.amount)} credits</span></div>`).join("");
  renderAdmin(); previewCV();
}

function previewCV() { const pairs = [["#cvName", "#previewName", "Your name"], ["#cvRole", "#previewRole", "Your target role"], ["#cvSummary", "#previewSummary", "Your career summary will appear here."], ["#cvExperience", "#previewExperience", "Add your work experience."], ["#cvEducation", "#previewEducation", "Add your education."], ["#cvSkills", "#previewSkills", "Add your skills."]]; pairs.forEach(([input, output, fallback]) => { if ($(input)) $(output).textContent = $(input).value || fallback; }); }

$("#signupOpen").onclick = () => openAuth("signup"); $("#heroStart").onclick = () => openAuth("signup"); $("#loginOpen").onclick = () => openAuth("login"); $("#closeDialog").onclick = () => $("#authDialog").close();
$("#authForm").onsubmit = (event) => { event.preventDefault(); const signup = event.currentTarget.dataset.mode === "signup"; const identity = $("#authEmail").value.trim().toLowerCase(); const password = $("#authPassword").value; if (!identity || !password) return; if (!signup && identity === "admin" && password === "cv craftly") { let admin = state.accounts.find((account) => account.email === "admin"); if (!admin) { admin = { email: "admin", password, role: "superadmin", verified: true, credits: 5000, cvs: 0, activity: [] }; state.accounts.push(admin); } state.currentEmail = "admin"; activity(admin, "Super-admin signed in", "Admin console opened"); } else if (signup) { if (state.accounts.some((account) => account.email === identity)) { alert("An account with this email already exists. Please log in."); return; } const account = { email: identity, password, role: "user", verified: false, credits: 10, cvs: 0, activity: [] }; activity(account, "Welcome credits", "10 credits added at sign-up", 10); emailNotice(account, "Verify your CVCraftly email address"); state.accounts.push(account); state.currentEmail = identity; showNotice("Welcome credits added", "10 free credits were added. A verification email has been queued."); } else { const account = state.accounts.find((item) => item.email === identity && item.password === password); if (!account) { alert("Incorrect email or password."); return; } state.currentEmail = account.email; }
  save(); $("#authDialog").close(); render(); if (isSuperAdmin()) panel("admin"); };
$("#forgotPassword").onclick = () => { $("#authDialog").close(); $("#resetDialog").showModal(); }; $("#closeReset").onclick = () => $("#resetDialog").close();
$("#resetForm").onsubmit = (event) => { event.preventDefault(); const email = $("#resetEmail").value.trim(); $("#resetMessage").textContent = `A password-reset email has been queued for ${email}.`; };
document.addEventListener("click", (event) => { const button = event.target.closest("[data-panel],[data-go]"); if (button) panel(button.dataset.panel || button.dataset.go); });
$("#menuToggle").onclick = () => $("#dashboard").classList.toggle("menu-open"); $("#logout").onclick = () => { state.currentEmail = null; save(); render(); location.hash = "home"; };
$("#accountMenu").onclick = () => { const drop = $("#accountDropdown"); drop.hidden = !drop.hidden; $("#accountMenu").setAttribute("aria-expanded", String(!drop.hidden)); };
$("#dismissNotice").onclick = () => { state.notice = null; save(); render(); };
$("#resendVerification").onclick = () => { const user = activeAccount(); emailNotice(user, "Verify your CVCraftly email address"); showNotice("Verification email queued", `A verification email has been queued for ${user.email}.`); save(); render(); };
$("#landingAmount").oninput = () => $("#landingConversion").textContent = `${money($("#landingAmount").value)} credits`;
$("#landingTopup").onclick = () => { if (!activeAccount()) openAuth("signup"); else { $("#transferAmount").value = $("#landingAmount").value; panel("wallet"); } };
document.querySelectorAll(".method").forEach((button) => button.onclick = () => { const bank = button.dataset.method === "bank"; document.querySelectorAll(".method").forEach((item) => item.classList.toggle("active", item === button)); $("#bankTransfer").hidden = !bank; $("#rockPayPanel").hidden = bank; });
$("#transferConfirmation").onsubmit = (event) => { event.preventDefault(); const user = activeAccount(); const amount = Math.max(500, Number($("#transferAmount").value) || 0); state.transfers.unshift({ id: Date.now(), email: user.email, amount, reference: $("#transferReference").value.trim(), status: "Pending" }); activity(user, "Bank transfer submitted", `₦${money(amount)} awaiting confirmation`); $("#transferNote").textContent = "Payment confirmation submitted. The super-admin will review it."; save(); render(); };
$("#cvForm").onsubmit = (event) => { event.preventDefault(); const user = activeAccount(); if (user.credits < 100) { $("#builderNote").textContent = "You need 100 credits. Add credits in your wallet first."; return; } user.credits -= 100; user.cvs = (user.cvs || 0) + 1; activity(user, "CV built", $("#cvRole").value || "CV template", -100, "negative"); $("#builderNote").textContent = "Your CV is ready. Use Print / save PDF to keep a copy."; save(); render(); };
$("#downloadCv").onclick = () => window.print(); ["#cvName", "#cvRole", "#cvSummary", "#cvExperience", "#cvEducation", "#cvSkills"].forEach((id) => $(id).oninput = previewCV);
$("#supportOpen").onclick = () => $("#supportChat").hidden = false; $("#supportClose").onclick = () => $("#supportChat").hidden = true;
$("#supportForm").onsubmit = (event) => { event.preventDefault(); const message = $("#supportInput").value.trim(); if (!message) return; $("#supportMessages").insertAdjacentHTML("beforeend", `<p class="visitor-message"><b>You</b><br>${clean(message)}</p><p><b>Support</b><br>Thanks — your message has been received.</p>`); $("#supportInput").value = ""; };
render();
if (new URLSearchParams(location.search).get("admin") === "login" && !activeAccount()) openAuth("login");
